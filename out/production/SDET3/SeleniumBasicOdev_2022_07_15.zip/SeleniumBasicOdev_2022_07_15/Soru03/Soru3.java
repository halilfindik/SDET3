package SeleniumBasicOdev_2022_07_15.Soru03;

import Utils.BaseStaticDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

public class Soru3 extends BaseStaticDriver {
    public static void main(String[] args) {
        driver.navigate().to("https://www.snapdeal.com/");

        WebElement searchBox=driver.findElement(By.id("inputValEnter"));
        searchBox.sendKeys("teddy bear");
        searchBox.sendKeys(Keys.RETURN);

        try {
            WebElement searchResult= driver.findElement(By.name("nnn"));
            if (searchResult.getText().equals("We've got 303 results for 'teddy bear'"))
                System.out.println("Test Passed...");
            else System.out.println("Test Failed...");
        } catch (Exception ex) {
        System.out.println("Hata oluştu : " + ex.getMessage().toLowerCase()); }

        BekleKapat();
    }
}
